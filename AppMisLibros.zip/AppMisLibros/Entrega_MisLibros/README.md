# Mis Libros

Proyecto del curso **Programación II** desarrollado con **React Native + Expo + TypeScript** para aplicar Programación Orientada a Objetos (POO) y Separación de Responsabilidades.

## Funcionalidades

- Visualizar una lista de libros.
- Agregar un libro con título, autor y año.
- Eliminar un libro.
- Validar que los campos estén completos y que el año sea numérico.

## Estructura

```text
App.tsx
   ↓
LibroService
   ↓
Libro
```

```text
Entrega_MisLibros/
├── App.tsx
├── README.md
├── app.json
├── package.json
├── tsconfig.json
├── assets/
│   └── captura-aplicacion.jpeg
└── src/
    ├── models/
    │   └── Libro.ts
    └── services/
        └── LibroService.ts
```

## Reflexión

### ¿Por qué es conveniente separar la lógica de los libros de App.tsx?

Porque `App.tsx` debe concentrarse principalmente en la interfaz y en la interacción con el usuario. Separar la lógica permite que el código sea más ordenado, fácil de entender, mantener y reutilizar. También evita que el componente principal tenga demasiadas responsabilidades.

### ¿Qué responsabilidad tiene LibroService?

`LibroService` administra la colección de libros. Se encarga de obtener la lista, agregar nuevos libros y eliminar libros. De esta manera, la lógica de administración no queda mezclada con la interfaz de usuario.

### ¿Qué responsabilidad tiene la clase Libro?

La clase `Libro` representa el modelo de cada libro. Almacena su `id`, `titulo`, `autor` y `anio`, utiliza propiedades privadas y métodos públicos para acceder a los datos, y contiene un comportamiento propio mediante `obtenerDescripcion()`.

## Conceptos de POO utilizados

La clase `Libro` utiliza constructor, propiedades, modificadores de acceso, encapsulamiento y métodos.

## Captura de la aplicación

![Captura de Mis Libros](assets/captura-aplicacion.jpeg)

## Ejecución

```bash
npm install
npx expo start
```
